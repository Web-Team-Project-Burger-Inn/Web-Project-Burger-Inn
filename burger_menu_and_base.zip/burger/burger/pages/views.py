
from decimal import Decimal

from django.shortcuts import render, redirect, get_object_or_404
from django.views.decorators.http import require_POST

from .models import Product


def menu(request):
    products = Product.objects.filter(
        available=True
    ).order_by("name")

    categories = (
        Product.objects.filter(available=True)
        .values_list("category", flat=True)
        .distinct()
    )

    return render(request, "pages/menu.html", {
        "products": products,
        "categories": categories,
    })


def add_to_cart(request, product_id):
    if request.method == "POST":
        product = get_object_or_404(
            Product,
            id=product_id,
            available=True
        )

        try:
            quantity = int(request.POST.get("quantity", 1))
        except (ValueError, TypeError):
            quantity = 1

        quantity = max(1, min(quantity, 99))

        cart_data = request.session.get("cart", {})
        key = str(product.id)

        cart_data[key] = min(
            cart_data.get(key, 0) + quantity,
            99
        )

        request.session["cart"] = cart_data

    return redirect("menu")


def cart(request):
    cart_data = request.session.get("cart", {})
    products = Product.objects.filter(
        id__in=cart_data.keys()
    )

    cart_items = []
    subtotal = Decimal("0.00")
    total_quantity = 0

    for product in products:
        quantity = cart_data.get(str(product.id), 0)

        if (
            not isinstance(quantity, int)
            or isinstance(quantity, bool)
            or quantity < 1
            or quantity > 99
        ):
            continue

        line_total = product.price * quantity

        cart_items.append({
            "product": product,
            "quantity": quantity,
            "line_total": line_total,
        })

        subtotal += line_total
        total_quantity += quantity

    return render(request, "pages/cart.html", {
        "cart_items": cart_items,
        "subtotal": subtotal,
        "total_quantity": total_quantity,
    })


@require_POST
def update_cart(request, product_id):
    cart_data = request.session.get("cart", {})

    if str(product_id) in cart_data:
        try:
            quantity = int(request.POST.get("quantity", 1))
        except (ValueError, TypeError):
            quantity = 1

        if quantity <= 0:
            cart_data.pop(str(product_id), None)
        else:
            cart_data[str(product_id)] = min(quantity, 99)

        request.session["cart"] = cart_data

    return redirect("cart")


@require_POST
def remove_from_cart(request, product_id):
    cart_data = request.session.get("cart", {})
    cart_data.pop(str(product_id), None)
    request.session["cart"] = cart_data

    return redirect("cart")


@require_POST
def clear_cart(request):
    request.session["cart"] = {}
    return redirect("cart")
