
def cart_summary(request):
    cart_data = request.session.get("cart", {})

    cart_count = sum(
        quantity
        for quantity in cart_data.values()
        if isinstance(quantity, int)
        and not isinstance(quantity, bool)
        and 1 <= quantity <= 99
    )

    return {
        "cart_count": cart_count,
    }
