
from django.shortcuts import get_object_or_404, render
from django.contrib.auth.decorators import login_required

from .models import Order


@login_required(login_url="login")
def track_order(request, order_number):

    order = get_object_or_404(
        Order,
        order_number=order_number,
        customer=request.user,
    )

    progress_steps = {
        'pending': 1,
        'preparing': 2,
        'out_for_delivery': 3,
        'delivered': 4,
    }

    progress_step = progress_steps.get(
        order.status,
        0
    )

    return render(
        request,
        'orders/track_order.html',
        {
            'order': order,
            'progress_step': progress_step,
        }
    )


def checkout_view(request):
    return render(request, 'orders/checkout.html')
