
from django.urls import path
from . import views

app_name = 'orders'

urlpatterns = [
    
    path(
        'checkout/',
        views.checkout_view,
        name='checkout'
    ),

    
    path(
        '<str:order_number>/',
        views.track_order,
        name='track_order'
    ),
]
