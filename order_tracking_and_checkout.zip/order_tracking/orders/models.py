
from django.conf import settings
from django.db import models


class Order(models.Model):

    STATUS_CHOICES = [
        ('pending', 'Order Placed'),
        ('preparing', 'Preparing'),
        ('out_for_delivery', 'Out for Delivery'),
        ('delivered', 'Delivered'),
        ('cancelled', 'Cancelled'),
    ]

    customer = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='restaurant_orders'
    )

    customer_name = models.CharField(max_length=100)
    phone = models.CharField(max_length=20)
    delivery_address = models.TextField()

    order_number = models.CharField(
        max_length=20,
        unique=True
    )

    items_summary = models.TextField()

    total_price = models.DecimalField(
        max_digits=10,
        decimal_places=2
    )

    status = models.CharField(
        max_length=20,
        choices=STATUS_CHOICES,
        default='pending'
    )

    estimated_delivery = models.DateTimeField(
        null=True,
        blank=True
    )

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"Order {self.order_number}"
