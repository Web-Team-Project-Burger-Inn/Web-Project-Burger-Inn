
from django.db import models


class Product(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField()
    price = models.DecimalField(max_digits=8, decimal_places=2)
    image_url = models.URLField(blank=True)
    category = models.CharField(max_length=50, default="Burgers")
    available = models.BooleanField(default=True)

    def __str__(self):
        return self.name
